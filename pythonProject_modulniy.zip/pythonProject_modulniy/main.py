# -*- coding: utf-8 -*-
import math
import mathematic.module1 as arm
import mathematic.module2 as pv
import mathematic.module3 as hd

if __name__ == '__main__':

   print(arm.delenie(float(input("Введите первое число ")), float(input("введите второе число "))))
   print(pv.logarifm(float(input("Введите логарифм какого числа надо рассчитать ")),
                     float(input("введите основание логарифма "))))
   print(pv.logarifm10(float(input("Введите десятичный логарифм какого числа надо рассчитать "))))
   print(pv.logarifm_2(float(input("Введите логарифм по основанию 2 какого числа надо рассчитать "))))
   print(pv.logarifm_n(float(input("Введите натуральный логарифм для  какого числа (х+1) надо рассчитать? "))))
   print(hd.fact_(int(input("Введите число для расчета факториал которого хотите рассчитать:"))))
   print(hd.fibo_(int(input("Введит число для вывода ряда Фибоначчи: "))))
   chislo = float(input("Введите число которое хотите округлить: "))
   step_okrug = int(input("Введите до какого знака после запятой вы хотите округлить: "))
   print(hd.okruglenie(chislo, step_okrug))