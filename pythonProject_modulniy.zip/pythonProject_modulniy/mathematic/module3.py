# -*- coding: utf-8 -*-
import math

def fact_(x):
    """Расчет факториала"""
    result = math.factorial(x)
    return result

def fibo_(x):
    """Рассчет числа Фибоначчи"""
    def fibonachchy(im):
        if im < 2:
            return im
        return fibonachchy(im - 1) + fibonachchy(im - 2)

    for im in range(x):
        print(f"Последовательность Фибоначчи {fibonachchy(im)}.")
    fibonachchy(x)

def okruglenie(x, y):
    result = round(x, y)
    return result

