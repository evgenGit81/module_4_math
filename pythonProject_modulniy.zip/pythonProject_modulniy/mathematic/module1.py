# -*- coding: utf-8 -*-

def summirovanie(x, y):
    """Сумма двух чисел"""
    z = x + y
    return z

def raznost(x=0, y=0):
    """Разность двух чисел"""
    z = x + y
    return z

def delenie(x=0, y=1):
    """Деление двух числе"""
    try:
        z = x / y
    except ZeroDivisionError:
        print("!!!Деление на ноль!")
        z = "ошибка"
    return z

def proizvedenie(x=1, y=0):
    """Произведение двух чисел"""
    z = x * y
    return z