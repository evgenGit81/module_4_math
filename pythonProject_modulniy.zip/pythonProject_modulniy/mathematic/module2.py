# -*- coding: utf-8 -*-
import math as mt

def logarifm(x, y):
    """Вычисление логарифма двух чисел"""
    try:
        z = mt.log(x, y)
    except ValueError:
        print("!!!Входные числа не должны равняться нулю!")
        z = "ошибка"
    except ZeroDivisionError:
        print("!!!Входные числа не должны равняться двум единицам!")
        z = "ошибка"
    return z

def logarifm10(x):
    """Вычисление десятичного логарифма"""
    try:
        z = mt.log10(x)
    except ValueError:
        print("!!!Входное число не должно равняться нулю!")
        z = "ошибка"
    return z

def logarifm_2(x):
    """Вычисление десятичного логарифма"""
    try:
        z = mt.log2(x)
    except ValueError:
        print("!!!Входное число не должно равняться нулю!")
        z = "ошибка"
    return z

def logarifm_n(x):
    """Вычисление десятичного логарифма"""
    try:
        z = mt.log1p(x)
    except ValueError:
        print("!!!Входное число не должно равняться нулю!")
        z = "ошибка"
    return z

def stepen(x, y):
    """Возводит в степень"""
    z = x ** y
    return z